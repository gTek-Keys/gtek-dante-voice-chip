# gTek Sovereign Governance AI

Welcome. Use the nav to browse the docs.
